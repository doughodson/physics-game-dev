#ifndef _PARTICLEHEADER
#define _PARTICLEHEADER

#include "mymath.h"

#define	 _GRAVITYACCELERATION		-9.8f		// Acceleration due to gravity in m/s^2
#define  _DRAGCOEFFICIENT			0.6f		// Nondimensional drag coefficient 
#define  _AIRDENSITY				1.23f		// Density of at at 15C in kg/m^3
#define  _WINDSPEED					0.1f		// Wind speed in m/s (10 m/s is almost 20 knots)
#define  _RESTITUTION				0.2f		// Coefficient of restitution


//------------------------------------------------------------------------//
// Particle structure
//------------------------------------------------------------------------//
class Particle {
public:
	float	fMass;						// Total mass
	Vector	vPosition;					// Position 
	Vector	vVelocity;					// Velocity
	float	fSpeed;						// Speed (magnitude of the velocity)
	Vector	vForces;					// Total force acting on the particle
	float	fRadius;					// Radius of particle used for collision detection
	Vector	vGravity;					// Gravity force vector
	Vector  vPreviousPosition;			// Position at previous time step (used for collision detection)
	Vector  vImpactForces;				// Used to aggregate collision impact forces
	bool	bCollision;

	Particle(void);						// Constructor
	void	CalcLoads(void);			// Aggregates all the forces acting on the particle
	void	UpdateBodyEuler(double dt); // Integrates one time step updating velocity and position
	void	Draw(void);					// Draws the particle
};

Vector	VRotate2D( float angle, Vector u);

#endif